/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package validararreglos;

import javax.swing.JOptionPane;
import java.util.Arrays;

/**
 *
 * @author danielsiles
 */
public class ValidarArreglos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        //ATRIBUTOS
        
        int arreglo1[] = new int[10] ;
        int arreglo2[] = new int[10];
        int suma[] = new int[10];
        
        // CICLO FOR PARA CREAR EL ARREGLO 1
        for (int i = 0; i <= 9 ; i++ ){
        
        arreglo1[i] = (int)(Math.random()*50+1);
        
        }
        
         // CICLO FOR PARA CREAR EL ARREGLO 2
        for (int i = 0; i <= 9 ; i++ ){
        
        arreglo2[i] = (int)(Math.random()*50 + 1);
        
        }
         //creamos otro FOR para mostrar los elementos del VECTOR #1
           System.out.println("El arreglo#1 ingresado es: ");
        for (int i = 0 ; i <= 9 ; i++){
           System.out.println(arreglo1[i]); 
        }
        
      //creamos otro FOR para mostrar los elementos del VECTOR #2
           System.out.println("El arreglo#2 ingresado es: ");
        for (int i = 0 ; i <= 9 ; i++){
           System.out.println(arreglo2[i]); 
        }
        
        //creamos otro FOR para calcular la suma de los elementos del VECTOR #3
         //  System.out.println("El arreglo#3 ingresado es: ");
       for (int i=0; i<= 9; i++){
               suma[i]= arreglo1[i] + arreglo2[i];
                
               }
            
        
          
            
            //IMPRESION ARREGLO #1
            String imprimir = "";
            imprimir += "ARREGLO #1 " + "\n";
            for(int i=0; i <= 9; i ++){
               imprimir += arreglo1[i];
               if(i == 9){
                  imprimir += "\n\n";
               } else {
               
                 imprimir += " ";
               }
            }
            
             //IMPRESION ARREGLO #2
            
            imprimir += "ARREGLO #2 " + "\n";
            for(int i=0; i <= 9; i ++){
               imprimir += arreglo2[i];
               if(i == 9){
                  imprimir += "\n\n";
               } else {
               
                 imprimir += " ";
               }
            }
            
           //CREAMOS VECTOR PARA IMPRIMIR LOS #s en SUMA, VECTOR #3
            int j = 9;
             // String imprimir = "";
            imprimir += "ARREGLO #3 " + "\n";
            while(j>=0) //j = 9
            {
              // for (int i=0; i<= 9; i++){
             //  suma[j]= arreglo1[i] + arreglo2[i];
                
              // }
            
           //    System.out.println("La suma del arreglo#3 en la posicion # " + j +  "  es: ");
       // for (int i = 0 ; i <= 9 ; i ++){
          
           imprimir += (suma[j]+" "); 
              j --;
        } 
          
            // JOptionPane.showMessageDialog(null,Arrays.toString(arreglo1));
            // JOptionPane.showMessageDialog(null,Arrays.toString(arreglo2));
             JOptionPane.showMessageDialog(null,imprimir);
            
            }
            
            
          
    }
    

